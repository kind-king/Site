<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "blog".
 *
 * @property string $id
 * @property string $title
 * @property string $description
 * @property string $body
 * @property integer $user_id
 * @property string $time_added
 * @property string $time_modified
 */
class Blog extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'blog';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['title', 'description', 'body', 'user_id'], 'required'],
            [['body'], 'string'],
            [['user_id'], 'integer'],
            [['time_added', 'time_modified'], 'safe'],
            [['title'], 'string', 'max' => 200],
            [['description'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Назва',
            'description' => 'Коротко',
            'body' => 'Повний текст',
            'user_id' => 'User ID',
            'time_added' => 'Time Added',
            'time_modified' => 'Time Modified',
        ];
    }
}
