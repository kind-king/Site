<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Про проект';
$this->params['breadcrumbs'][] = $this->title;
?>

