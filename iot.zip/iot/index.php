<?php
/**
 * Created by PhpStorm.
 * User: nimda
 * Date: 18.05.2015
 * Time: 10:33
 */
header('Location: web/');